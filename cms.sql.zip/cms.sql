-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 12, 2019 at 10:10 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(3) NOT NULL,
  `cat_title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(1, 'Top 100'),
(6, 'Theme'),
(7, 'MV'),
(8, 'Singer'),
(9, 'Album'),
(10, 'Playlist');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comment_id` int(3) NOT NULL,
  `comment_post_id` int(3) NOT NULL,
  `comment_author` varchar(255) NOT NULL,
  `comment_email` varchar(255) NOT NULL,
  `comment_content` text NOT NULL,
  `comment_status` varchar(255) NOT NULL,
  `comment_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comment_id`, `comment_post_id`, `comment_author`, `comment_email`, `comment_content`, `comment_status`, `comment_date`) VALUES
(1, 1, 'Coldplay', '123456@gmail.com', 'I used to rule the world Seas would rise when I gave the word Now in the morning, I sleep alone Sweep the streets I used to own', 'approve', '2019-09-11'),
(2, 2, 'thinh', 'thinh123@gmail.com', 'tpt', 'approve', '2019-09-11'),
(5, 2, 'harry', 'hraaa@gmail.com', 'adasdasd123', 'approve', '2019-09-12'),
(6, 3, '456', 'hraaa456@gmail.com', 'ddddddddddddddddddddddddd', 'approve', '2019-09-12'),
(8, 3, '456', 'hraaa456@gmail.com', 'ddddddddddddddddddddddddd', 'approve', '2019-09-12'),
(10, 33, 'thinh', 'thinh123@gmail.com', '1132135461', 'approve', '2019-09-12'),
(16, 33, '123', '123aaaa@gmail.com', 'aaaaaaaaa', 'approve', '2019-09-12'),
(17, 2, 'harry', 'hraaa@gmail.com', '0123', 'approve', '2019-09-12');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `post_id` int(3) NOT NULL,
  `post_category_id` int(3) NOT NULL,
  `post_title` varchar(255) NOT NULL,
  `post_author` varchar(255) NOT NULL,
  `post_date` date NOT NULL,
  `post_image` text NOT NULL,
  `post_content` text NOT NULL,
  `post_tags` varchar(255) NOT NULL,
  `post_comment_count` varchar(255) NOT NULL,
  `post_status` varchar(255) NOT NULL DEFAULT 'draft',
  `points` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`post_id`, `post_category_id`, `post_title`, `post_author`, `post_date`, `post_image`, `post_content`, `post_tags`, `post_comment_count`, `post_status`, `points`) VALUES
(1, 1, 'Viva la vida', 'Coldplay', '2019-09-11', 'cms_img_viva.jpg', 'I used to rule the world\r\nSeas would rise when I gave the word\r\nNow in the morning, I sleep alone\r\nSweep the streets I used to own', 'th20n13, songs, lyrics', '0', 'draft', 15),
(2, 2, 'Scar (Secret Garden OST)', 'Bois', '2019-09-11', 'cms_img_scar.jpg', 'I turned around many times already\r\nI laughed like it was nothing\r\nEven if I lied to my heart without words\r\nAre you wandering because you don’t know my heart\r\nSuddenly I’m afraid, saying I love you\r\nThey’re not words I’m used to saying\r\nWith hardened lips, I love you, I love you\r\nI am shouting those words on your back\r\n', 'songs, lyrics, bois', '1', 'draft', 4),
(3, 3, 'Only Teardrops', 'Emmelie De Forest', '2019-09-06', 'cms_img_tearsdrops.jpg', 'Eye for an eye, why tear each other apart?\r\nPlease tell me why, why do we make it so hard?\r\nLook at us now, we only got ourselves to blame\r\nIt\'s such a shame\r\nHow many times can we win and lose?\r\nHow many times can we break the rules between us?\r\nOnly teardrops', 'only tearsdrop, emelie, lyrics', '', 'draft', 5),
(33, 1, 'While your lips are still red', 'NightWish', '2019-09-12', 'cms.img.nightwish.jpg', '  Sweet little words made for silence not talk\r\nYoung heart for love not heartache\r\nDark hair for catching the wind\r\nNot to veil the sight of a cold world                ', 'nightwish,lips, lyrics, songs', '8', 'draft', 19),
(38, 123, 'Hard Rock', 'Lordi', '2019-09-11', 'download.jpg', 'aaaaaaaaaaaaaaaaaaaaa', 'nightwish,lips, lyrics, songs', '4', 'aaaaa', 6),
(39, 7, 'Ronaldo', 'th208n16', '2019-09-12', 'Ronaldo.jpg', '132456', 'ronaldo, sports, football, juve', '', 'draft', 16);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`post_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comment_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `post_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
